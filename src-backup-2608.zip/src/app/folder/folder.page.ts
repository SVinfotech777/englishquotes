import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NavController } from '@ionic/angular';
import {
  AdMob,
  AdOptions,
  BannerAdOptions,
  BannerAdPosition,
  BannerAdSize,
} from '@capacitor-community/admob';
import { Preferences } from '@capacitor/preferences';
import { HttpClient } from '@angular/common/http';
import { AlertService } from '../provider/alert.service';
import { Clipboard } from '@capacitor/clipboard';
import { Share } from '@capacitor/share';
import { TextToSpeech } from '@capacitor-community/text-to-speech';
import { base_URL } from '../app-constant';
@Component({
  selector: 'app-folder',
  templateUrl: './folder.page.html',
  styleUrls: ['./folder.page.scss'],
})
export class FolderPage implements OnInit {
  categoryData: any;
  isFav: boolean = false;
  isShow: boolean = false;
  filterList: any[] = [];
  shayariList: any[] = [];

  constructor(
    private activatedRoute: ActivatedRoute,
    public navCtrl: NavController,
    public router: Router,
    public http: HttpClient,
    public alertService: AlertService
  ) {
    this.activatedRoute.queryParams.subscribe((params) => {
      if (params && params['category']) {
        this.categoryData = JSON.parse(params['category']);
      }
    });
  }

  async showInterstitial() {
    const options: AdOptions = {
      adId: 'ca-app-pub-3228515841874235/8618042809',
      isTesting: true
    };
    await AdMob.prepareInterstitial(options);
    await AdMob.showInterstitial();
  }

  async ngOnInit() {
    await this.initialize();
    this.banner();
    await this.showInterstitial();
  }

  async gotoBack() {
    await this.stopTextToSpeech();
    this.router.navigateByUrl('');
  }

  async ionViewDidEnter() {
    await this.alertService.presentLoader('');
    await this.readDataFromPref();
  }

  async readDataFromPref() {
    let latestList: any[] = [];
    latestList = await this.readShayariFromDb();
    // get shayari list from storage
    let shayariList: any = await Preferences.get({ key: 'favoriteShayari' });
    if (shayariList && !shayariList.value) {
      if (latestList.length > 0) {
        this.filterList = latestList;
      }
      await this.alertService.dismissLoader();
      this.isShow = true;
    } else {
      let prefShayariList = JSON.parse(shayariList.value);
      if (this.categoryData) {
        prefShayariList = prefShayariList.filter((shayari: any) => {
          return shayari.categoryId == this.categoryData.key;
        });
      }
      if (latestList.length > 0) {
        latestList.forEach((element) => {
          let index = prefShayariList.findIndex((ele: any) => {
            return ele.key === element.key;
          });
          if (index == -1) {
            prefShayariList.push({...element, isFav: false});
          } else {
            prefShayariList[index].isFav = true;
          }
        });
      }
      this.filterList = prefShayariList;
      this.filterList = this.filterList.map(shayari => {
        shayari.isPlay = false;
        return shayari;
      })
      await this.alertService.dismissLoader();
      this.isShow = true;
    }

  }

  async initialize() {
    await AdMob.initialize({
      requestTrackingAuthorization: true,
      initializeForTesting: true,
    })
  }

  isShowBanner: boolean = false;
  banner() {
    try {
      const options: BannerAdOptions = {
        adId: 'ca-app-pub-3228515841874235/7778205051',
        adSize: BannerAdSize.FULL_BANNER,
        position: BannerAdPosition.BOTTOM_CENTER,
        margin: 0,
        isTesting: true
      };
      AdMob.showBanner(options).then(
        (res) => {
          this.isShowBanner = true;
        },
        (err) => {
        }
      );
     } catch (err) {
     }
  }

  async stopTextToSpeech() {
    await TextToSpeech.stop();
    this.filterList.map(item => {
      item.isPlay = false
    })
  }

  async ngOnDestroy() {
    if(this.isShowBanner) AdMob.removeBanner()
    await this.stopTextToSpeech();
  }

  readShayariFromDb() {
    return new Promise<any>((resolve, reject) => {
      this.http
        .get(
          `${base_URL}quotes/${this.categoryData.key}.json`
        )
        .subscribe(
          (res) => {
            let list: any[] = [];
            if (res) list = this.alertService.convertObjToArr(res);
            if (list.length > 0) {
              list.forEach((element) => {
                element.categoryId = this.categoryData.key;
              });
            }
            resolve(list);
          },
          (err) => {
            resolve([]);
          }
        );
    });
  }

  // Copy quote
  copyClipboard(shayari: any) {
    Clipboard.write({ string: this.alertService.removeBrFromStr(shayari.name) })
      .then((res) => {
        // this.alertService.presentToast('Copied Successfully');
      })
      .catch((e) => {
        console.log('e', e);
      });
  }

  // Bookmark
  async favorite(shayari: any) {
    shayari.isFav = !shayari.isFav;
    let index = this.filterList.findIndex((ele) => {
      return ele.key == shayari.key;
    });
    if (index > -1) {
      this.filterList[index] = shayari;
    }
    await this.setShayariInPref(shayari);
    // this.alertService.presentToast(shayari.isFav ? 'Marked' : 'Unmarked');
  }


  async setShayariInPref(shayari: any) {
    let list: any[] = [];
    let prefData: any = await Preferences.get({ key: 'favoriteShayari' });
    if (prefData && !prefData.value) {
      list.push(shayari);
    } else {
      list = JSON.parse(prefData.value);
      let index = list.findIndex((element) => {
        return element.key == shayari.key;
      });
      if (index > -1) {
        list.splice(index, 1);
      } else {
        list.push(shayari);
      }
    }
    await Preferences.set({ key: 'favoriteShayari', value: JSON.stringify(list) });
  }

  // Social Share
  socialShare(shayari: any) {
    Share.share({ text: this.alertService.removeBrFromStr(shayari.name) });
  }

  isPlayRunning: boolean = false;
  async speak(shayari: any) {
    if(shayari.isPlay) return;
    shayari.isPlay = true;
    let obj = {
      text: shayari.name.replace(/<br\s*\/?>/gi,''),
      lang: 'hi-IN',
      rate: 1.0,
      pitch: 1.0,
      volume: 1.0,
      category: 'ambient',
    }
    TextToSpeech.speak(obj).then(res => {
      shayari.isPlay = false;
    })

    this.filterList.map(item => {
      if(item.key != shayari.key) item.isPlay = false
    })

  }

  async stopSpeaking(shayari: any) {
    await TextToSpeech.stop();
    shayari.isPlay = false;
  }
}
